﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Items
{
    public enum BatteryType
    {
        Li_Ion = 0,
        NiMH = 1,
        NiCd = 2
    }
}
